# Clips Kitty – Android (pano geçmişi yöneticisi)

> Not: Orijinal Windows kurulum dosyası sadece bir "web installer" olduğu için
> içinden uygulama analiz edilemedi. Bu proje, uygulamanın adından/amacından
> (pano geçmişi yöneticisi) yola çıkılarak yazılmış Android karşılığıdır.

## Özellikler
| Özellik | Android'deki yolu |
|---|---|
| Pano geçmişi | SQLite (`ClipDb`), en fazla 500 kayıt, tekrarlar öne taşınır |
| Arka planda pano dinleme | `ClipboardService` (foreground service) |
| Arama | Ana ekrandaki arama kutusu |
| Sabitleme / silme / paylaşma | Kayda uzun bas |
| Tek dokunuşla tekrar kopyalama | Kayda dokun |
| Global kısayol yerine | Hızlı Ayarlar karosu + bildirimdeki "Şimdi kaydet" |
| Seçili metni kaydet | Metin seçince menüde "Clips Kitty'ye kaydet" / Paylaş |
| Hassas içerik koruması | `IS_SENSITIVE` işaretli (şifre yöneticisi) kopyalar atlanır |

## Android sınırı
Android 10+ arka plandaki uygulamaların panoyu okumasını engeller. Bu yüzden:
- Uygulama açıkken / odaktayken otomatik kaydeder.
- Başka uygulamada kopyalayınca: Hızlı Ayarlar karosuna (düzenle menüsünden ekle)
  veya bildirimdeki "Şimdi kaydet" düğmesine bas.
- Tam otomatik kayıt için klavye (IME) veya erişilebilirlik servisi gerekir.

## Build
1. Android Studio (Koala veya yeni) ile klasörü aç, Gradle sync bekle (JDK 17).
2. `Build > Build APK(s)` → `app/build/outputs/apk/debug/app-debug.apk`
3. Telefonda "bilinmeyen kaynaklardan kur" izni ver ve APK'yı yükle.

Minimum Android 8.0 (API 26), hedef Android 14 (API 34).
