package com.clipskitty.android

import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/** Saydam aktivite: odak alinca panoyu okur, kaydeder, kapanir. */
class CaptureActivity : AppCompatActivity() {
    private var done = false

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || done) return
        done = true
        val text = ClipUtil.readText(this)
        if (text != null && ClipDb.get(this).add(text)) {
            Toast.makeText(this, R.string.saved, Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, R.string.nothing, Toast.LENGTH_SHORT).show()
        }
        finish()
    }
}
