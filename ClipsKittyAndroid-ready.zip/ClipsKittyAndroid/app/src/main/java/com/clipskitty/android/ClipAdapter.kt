package com.clipskitty.android

import android.text.format.DateUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ClipAdapter(
    private val onClick: (ClipItem) -> Unit,
    private val onLong: (ClipItem) -> Unit
) : RecyclerView.Adapter<ClipAdapter.VH>() {

    private var items: List<ClipItem> = emptyList()

    @Suppress("NotifyDataSetChanged")
    fun submit(list: List<ClipItem>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val txt: TextView = v.findViewById(R.id.txt)
        val meta: TextView = v.findViewById(R.id.meta)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_clip, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = items[position]
        h.txt.text = item.text
        val rel = DateUtils.getRelativeTimeSpanString(
            item.created, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS
        )
        h.meta.text = if (item.pinned) "📌 $rel" else rel.toString()
        h.itemView.setOnClickListener { onClick(item) }
        h.itemView.setOnLongClickListener { onLong(item); true }
    }
}
