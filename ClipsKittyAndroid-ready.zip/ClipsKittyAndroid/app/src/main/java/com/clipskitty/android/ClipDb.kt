package com.clipskitty.android

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Handler
import android.os.Looper

data class ClipItem(val id: Long, val text: String, val created: Long, val pinned: Boolean)

class ClipDb private constructor(ctx: Context) :
    SQLiteOpenHelper(ctx.applicationContext, "clips.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE clips(id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "text TEXT NOT NULL, created INTEGER NOT NULL, pinned INTEGER NOT NULL DEFAULT 0)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    /** Ayni metin varsa one tasir, yoksa ekler. */
    @Synchronized
    fun add(text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty() || t.length > MAX_LEN) return false
        val db = writableDatabase
        val now = System.currentTimeMillis()
        db.query("clips", arrayOf("id"), "text=?", arrayOf(t), null, null, null).use { c ->
            if (c.moveToFirst()) {
                val cv = ContentValues().apply { put("created", now) }
                db.update("clips", cv, "id=?", arrayOf(c.getLong(0).toString()))
            } else {
                val cv = ContentValues().apply {
                    put("text", t); put("created", now); put("pinned", 0)
                }
                db.insert("clips", null, cv)
            }
        }
        db.execSQL(
            "DELETE FROM clips WHERE pinned=0 AND id NOT IN " +
                "(SELECT id FROM clips WHERE pinned=0 ORDER BY created DESC LIMIT $MAX_ITEMS)"
        )
        notifyChanged()
        return true
    }

    @Synchronized
    fun list(query: String?): List<ClipItem> {
        val q = query?.trim().orEmpty()
        val sel = if (q.isEmpty()) null else "text LIKE ?"
        val args = if (q.isEmpty()) null else arrayOf("%$q%")
        val out = ArrayList<ClipItem>()
        readableDatabase.query(
            "clips", arrayOf("id", "text", "created", "pinned"),
            sel, args, null, null, "pinned DESC, created DESC"
        ).use { c ->
            while (c.moveToNext()) {
                out.add(ClipItem(c.getLong(0), c.getString(1), c.getLong(2), c.getInt(3) == 1))
            }
        }
        return out
    }

    @Synchronized
    fun togglePin(item: ClipItem) {
        val cv = ContentValues().apply { put("pinned", if (item.pinned) 0 else 1) }
        writableDatabase.update("clips", cv, "id=?", arrayOf(item.id.toString()))
        notifyChanged()
    }

    @Synchronized
    fun delete(item: ClipItem) {
        writableDatabase.delete("clips", "id=?", arrayOf(item.id.toString()))
        notifyChanged()
    }

    @Synchronized
    fun clearUnpinned() {
        writableDatabase.delete("clips", "pinned=0", null)
        notifyChanged()
    }

    private fun notifyChanged() {
        Handler(Looper.getMainLooper()).post { onChange?.invoke() }
    }

    companion object {
        private const val MAX_ITEMS = 500
        private const val MAX_LEN = 100_000

        @Volatile private var inst: ClipDb? = null
        var onChange: (() -> Unit)? = null

        fun get(ctx: Context): ClipDb =
            inst ?: synchronized(this) { inst ?: ClipDb(ctx).also { inst = it } }
    }
}
