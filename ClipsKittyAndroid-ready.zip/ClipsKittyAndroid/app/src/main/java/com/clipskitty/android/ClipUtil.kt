package com.clipskitty.android

import android.content.ClipboardManager
import android.content.Context

object ClipUtil {
    /** Panodaki metni okur. Hassas isaretli (sifre yoneticisi vb.) icerikleri atlar. */
    fun readText(ctx: Context): String? {
        return try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip ?: return null
            if (clip.itemCount == 0) return null
            val sensitive = clip.description.extras
                ?.getBoolean("android.content.extra.IS_SENSITIVE", false) == true
            if (sensitive) return null
            clip.getItemAt(0).coerceToText(ctx)?.toString()?.takeIf { it.isNotBlank() }
        } catch (e: Exception) {
            null
        }
    }
}
