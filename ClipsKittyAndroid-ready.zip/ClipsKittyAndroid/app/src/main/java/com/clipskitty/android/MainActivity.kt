package com.clipskitty.android

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var clipAdapter: ClipAdapter
    private lateinit var search: EditText
    private val db by lazy { ClipDb.get(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        search = findViewById(R.id.search)
        clipAdapter = ClipAdapter(onClick = { copy(it) }, onLong = { showMenu(it) })
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = clipAdapter
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = refresh()
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })

        findViewById<Button>(R.id.capture).setOnClickListener { captureNow(true) }
        findViewById<Button>(R.id.clear).setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage(R.string.clear_confirm)
                .setPositiveButton(R.string.yes) { _, _ -> db.clearUnpinned() }
                .setNegativeButton(R.string.no, null)
                .show()
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        try {
            ContextCompat.startForegroundService(this, Intent(this, ClipboardService::class.java))
        } catch (_: Exception) {
        }
    }

    override fun onResume() {
        super.onResume()
        ClipDb.onChange = { refresh() }
        refresh()
    }

    override fun onPause() {
        ClipDb.onChange = null
        super.onPause()
    }

    // Uygulama odak alinca panoyu otomatik kaydet (Android 10+ icin izinli yol)
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) captureNow(false)
    }

    private fun captureNow(toast: Boolean) {
        val text = ClipUtil.readText(this)
        val ok = text != null && db.add(text)
        if (toast) {
            Toast.makeText(this, if (ok) R.string.saved else R.string.nothing, Toast.LENGTH_SHORT).show()
        }
        refresh()
    }

    private fun refresh() = clipAdapter.submit(db.list(search.text?.toString()))

    private fun copy(item: ClipItem) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("clip", item.text))
        Toast.makeText(this, R.string.copied, Toast.LENGTH_SHORT).show()
    }

    private fun showMenu(item: ClipItem) {
        val options = arrayOf(
            getString(if (item.pinned) R.string.unpin else R.string.pin),
            getString(R.string.share),
            getString(R.string.delete)
        )
        AlertDialog.Builder(this).setItems(options) { _, i ->
            when (i) {
                0 -> db.togglePin(item)
                1 -> startActivity(
                    Intent.createChooser(
                        Intent(Intent.ACTION_SEND).setType("text/plain")
                            .putExtra(Intent.EXTRA_TEXT, item.text), null
                    )
                )
                2 -> db.delete(item)
            }
        }.show()
    }
}
