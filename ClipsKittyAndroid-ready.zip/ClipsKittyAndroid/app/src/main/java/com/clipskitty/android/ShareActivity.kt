package com.clipskitty.android

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/** "Paylas" menusu ve metin secimindeki "Clips Kitty'ye kaydet" girisi. */
class ShareActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text: CharSequence? = when (intent?.action) {
            Intent.ACTION_SEND -> intent.getCharSequenceExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_PROCESS_TEXT -> intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)
            else -> null
        }
        if (text != null && ClipDb.get(this).add(text.toString())) {
            Toast.makeText(this, R.string.saved, Toast.LENGTH_SHORT).show()
        }
        finish()
    }
}
